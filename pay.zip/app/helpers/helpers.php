<?php

use App\Exceptions\Api\V2\DepositMoneyException;

use App\Models\{Bank,
    CurrencyPaymentMethod,
    Parameter,
    Transaction,
    Withdrawal,
    User
};
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Session;
use \App\Models\CryptoProvider;

if (!function_exists('setDateForDb')) {
    /**
     * format date time for Database
     *
     * @param  mixed $value
     * @return void
     */
    function setDateForDb($value)
    {
        $separator = session('date_sepa');
        $dateFormat = session('date_format_type');

        if (str_replace($separator, '', $dateFormat) == "mmddyyyy") {
            $value = str_replace($separator, '/', $value);
            $date  = date('Y-m-d', strtotime($value));
        } else {
            $date = date('Y-m-d', strtotime(strtr($value, $separator, '-')));
        }

        return $date;
    }
}

if (!function_exists('unique_code')) {
    /**
     * unique_code
     *
     * @param  int $length
     * @return string
     */
    function unique_code(int $length = 13): string
    {
        if (function_exists("random_bytes")) {
            $bytes = random_bytes(ceil($length / 2));
        } elseif (function_exists("openssl_random_pseudo_bytes")) {
            $bytes = openssl_random_pseudo_bytes(ceil($length / 2));
        } else {
            throw new Exception(__('There is currently no random function that meets the standards of cryptographic security.'));
        }

        return strtoupper(substr(bin2hex($bytes), 0, $length));
    }
}

/**
 * [dateFormat description]
 * @param  [type] $value    [any number]
 * @return [type] [formates date according to preferences setting in Admin Panel]
 */
function dateFormat($value, $userId = null) //$userId - needed for using user_id for mobile app (as mobile app does not know auth()->user()->id)
{
    $timezone = '';
    $prefix   = str_replace('/', '', request()->route()->getPrefix());
    if ($prefix == config('adminPrefix')) {
        $timezone = preference('dflt_timezone');
    } else {
        if (!empty($userId)) {
            $user = App\Models\User::with('user_detail:user_id,timezone')->where(['id' => $userId])->first(['id']);
        } else {
            if (!empty(auth()->user()->id)) {
                $user = App\Models\User::with('user_detail:user_id,timezone')->where(['id' => auth()->user()->id])->first(['id']);
            }
        }
        if (!empty(auth()->user()->id) || !empty($userId)) {
            $timezone = $user->user_detail->timezone;
        } else {
            $timezone = 'UTC';
        }
    }
    $today = new DateTime($value, new DateTimeZone(config('app.timezone')));
    $today->setTimezone(new DateTimeZone($timezone));
    $value = $today->format('Y-m-d H:i:s');

    $preferenceData = \App\Models\Preference::where(['category' => 'preference'])->whereIn('field', ['date_format_type', 'date_sepa'])->get(['field', 'value'])->toArray();
    $preferenceData = App\Http\Helpers\Common::key_value('field', 'value', $preferenceData);
    $preference     = $preferenceData['date_format_type'];
    $separator      = $preferenceData['date_sepa'];

    $data   = str_replace(['/', '.', ' ', '-'], $separator, $preference);
    $data   = explode($separator, $data);
    $first  = $data[0];
    $second = $data[1];
    $third  = $data[2];

    $dateInfo = str_replace(['/', '.', ' ', '-'], $separator, $value);
    $datas    = explode($separator, $dateInfo);
    $year     = $datas[0];
    $month    = $datas[1];
    $day      = $datas[2];

    $dateObj   = DateTime::createFromFormat('!m', $month);
    $monthName = $dateObj->format('F');

    $toHoursMin = \Carbon\Carbon::createFromTimeStamp(strtotime($value))->format(' g:i A');
    if ($first == 'yyyy' && $second == 'mm' && $third == 'dd') {
        $value = $year . $separator . $month . $separator . $day . $toHoursMin;
    } elseif ($first == 'dd' && $second == 'mm' && $third == 'yyyy') {
        $value = $day . $separator . $month . $separator . $year . $toHoursMin;
    } elseif ($first == 'mm' && $second == 'dd' && $third == 'yyyy') {
        $value = $month . $separator . $day . $separator . $year . $toHoursMin;
    } elseif ($first == 'dd' && $second == 'M' && $third == 'yyyy') {
        $value = $day . $separator . $monthName . $separator . $year . $toHoursMin;
    } elseif ($first == 'yyyy' && $second == 'M' && $third == 'dd') {
        $value = $year . $separator . $monthName . $separator . $day . $toHoursMin;
    }
    return $value;

}

/**
 * [roundFormat description]
 * @param  [type] $value   [any number]
 * @return [type] [formats to 2 decimal places]
 */
function decimalFormat($value)
{
    $preference = preference('decimal_format_amount', 2);
    return number_format((float) ($value), $preference, '.', '');
}

if (!function_exists('cryptoFormat')) {

    function cryptoFormat($value)
    {
        $preference = preference('decimal_format_amount_crypto', 8);
        return number_format((float) ($value), $preference, '.', '');
    }
}

if (!function_exists('tokenFormat')) {

    function tokenFormat($value, $decimal)
    {
        return number_format((float) ($value), $decimal, '.', '');
    }
}

if (!function_exists('tokenMinLimit')) {

    function tokenMinLimit($decimal)
    {
        return pow(10, -$decimal);
    }
}

/**
 * [roundFormat description]
 * @param  [type] $value     [any number]
 * @return [type] [placement of money symbol according to preferences setting in Admin Panel]
 */
function moneyFormat($symbol, $value)
{
    if (!empty($symbol)) {
        if (preference('money_format') == "before") {
            return $symbol . ' ' . $value;
        }
        return $value . ' ' . $symbol;
    }
    return $value;
}

function moneyFormatForDashboardProgressBars($symbol, $value)
{
    return moneyFormat($symbol, $value);
}

//function to set pages position on frontend
function getMenuContent($position)
{
    return \App\Models\Pages::where('position', 'like', "%$position%")->whereStatus('active')->get(['url', 'name']);
}

if (!function_exists('getSocialLink')) {
    function getSocialLink()
    {
        return DB::table('socials')->select('url', 'icon')->whereNotNull('url')->get()
            ->toArray();
    }
}

if (!function_exists('meta')) {
    function meta($url, $field)
    {
        $meta = \App\Models\Meta::where('url', $url)->value($field);

        if ($meta !== null) {
            return $meta;
        } elseif (in_array($field, ['title', 'description', 'keyword'])) {
            return __("Page Not Found");
        }

        return "";
    }
}

function getTime($date)
{
    return date("H:i A", strtotime($date));
}

function changeEnvironmentVariable($key, $value)
{
    $path = base_path('.env');

    if (is_bool(env($key))) {
        $old = env($key) ? 'true' : 'false';
    } elseif (env($key) === null) {
        $old = 'null';
    } else {
        $old = env($key);
    }

    if (file_exists($path)) {
        if ($old == 'null') {
            file_put_contents($path, "\n$key=" . str_replace(' ', '', $value), FILE_APPEND);
        } else {
            file_put_contents($path, str_replace(
                "$key=" . $old, "$key=" . str_replace(' ', '', $value), file_get_contents($path)
            ));
        }
    }
}

function trimExtraZeros($num) {
    $isDecimal = strpos($num, '.') || strpos($num, ',');

    if ($isDecimal === false) {
        return $num;
    } else {
        $dotPos = strpos(strrev($num), '.');
        $commaPos = strpos(strrev($num), ',');

        if ($dotPos < $commaPos) {
            $num =  rtrim(rtrim($num, '0'), '.');
        } else {
            $num =  rtrim(rtrim($num, '0'), ',');
        }

        if (substr($num, -1) == '.') {
            return str_replace('.', '', $num);
        } else if (substr($num, -1) == ',') {
            return str_replace(',', '', $num);
        }
        return $num;
    }
}

function formatNumber($num = 0, $currencyId = NULL)
{
    $currencyType = 'fiat';
    if ($currencyId !== null) {
        $currencyType = \App\Models\Currency::where('id', $currencyId)->value('type');
    }

    $seperator = preference('thousand_separator', '.');
    $format =  ($currencyType == 'fiat') ? preference('decimal_format_amount', 2) : preference('decimal_format_amount_crypto', 8);

    if ($seperator == '.') {
        $num = trimExtraZeros(number_format($num, (int)$format, ",", "."));
    } else if ($seperator == ',') {
        $num = trimExtraZeros(number_format($num, (int)$format, ".", ","));
    }
    return $num;
}

if (!function_exists('getLanguagesListAtFooterFrontEnd')) {
    function getLanguagesListAtFooterFrontEnd()
    {
        return App\Models\Language::where(['status' => 'Active'])->get(['short_name', 'name']);
    }
}

if (!function_exists('getAppStoreLinkFrontEnd')) {
    function getAppStoreLinkFrontEnd()
    {
        return App\Models\AppStoreCredentials::where(['has_app_credentials' => 'Yes'])->get(['logo', 'link', 'company']);
    }
}

if (!function_exists('isEnabledExchangeApi')) {
    /**
     * Checking which currency exchange api is enabled
     *
     * @return bool
     */
    function isEnabledExchangeApi(): bool
    {
        if (settings('exchange_enabled_api') != 'Disabled') {
            return settings('currency_exchange_rate')[settings('exchange_enabled_api')] ?? false;
        }
        return false;
    }
}

if (!function_exists('getApiCurrencyRate')) {
    /**
     * Get currency exchange rate from external api
     *
     * @return double
     */
    function getApiCurrencyRate($fromCurrencyCode, $toCurrencryCode)
    {
        $exchangeResolver = (new App\Resolvers\ExchangeApiResolver())->resolveService(settings('exchange_enabled_api'), $fromCurrencyCode, $toCurrencryCode);
        return $exchangeResolver->getCurrencyRate();
    }
}

if (!function_exists('getLocalCurrencyRate')) {
    /**
     * Get currency exchange rate based on local exchange rates
     *
     * @return double
     */
    function getLocalCurrencyRate($fromCurrencyRate, $toCurrencyRate)
    {
        $defaultCurrency = (new \App\Http\Helpers\Common)->getCurrencyObject(['default' => 1], ['rate']);
        return ($defaultCurrency->rate / $fromCurrencyRate) * $toCurrencyRate;
    }
}

if (!function_exists('setActionSession')) {
    /**
     * setActionSession
     * @return void
     */
    function setActionSession()
    {
        $key = time();
        $encryptedKey = Illuminate\Support\Facades\Crypt::encrypt($key);
        session(['action-session' => $encryptedKey]);
        session(['session-key' => $key]);
    }
}

if (!function_exists('actionSessionCheck')) {
    /**
     * actionSessionCheck
     * @return void
     */
    function actionSessionCheck()
    {
        if (! Illuminate\Support\Facades\Session::has('action-session')) {
            abort(404);
        }

        $key = session('session-key');
        $encryptedKey = session('action-session');

        if ($key != Illuminate\Support\Facades\Crypt::decrypt($encryptedKey)) {
            abort(404);
        }
    }
}

if (!function_exists('clearActionSession')) {
    /**
     * actionSessionCheck
     * @return void
     */
    function clearActionSession()
    {
        Illuminate\Support\Facades\Session::forget(['action-session', 'session-key']);
    }
}

if (!function_exists('getCurrencyIdOfTransaction')) {
    /**
     * getCurrencyIdOfTransaction
     * @param  array $transactions
     * @return array
     */
    function getCurrencyIdOfTransaction($transactions)
    {
        $currencies = [];
        foreach ($transactions as $transaction)
        {
            $currencies[] = $transaction->currency_id;
        }
        return $currencies;
    }
}

//fixed - for exchange rate - if set to 0 - which is unusual
function generateAmountBasedOnDfltCurrency($data, $currencyWithRate)
{
    $data_map = [];
    foreach ($data as $key => $value)
    {
        foreach ($currencyWithRate as $currencyRate)
        {
            if ($currencyRate->id == $value->currency_id)
            {
                if (!isset($data_map[$value->day][$value->month]))
                {
                    $data_map[$value->day][$value->month] = 0;
                }
                if ($value->currency_id != session('default_currency'))
                {
                    if ($currencyRate->rate != 0)
                    {
                        $data_map[$value->day][$value->month] += abs($value->amount / $currencyRate->rate);
                    }
                    else
                    {
                        $data_map[$value->day][$value->month] = 0;
                    }
                }
                else
                {
                    $data_map[$value->day][$value->month] += abs($value->amount);
                }
            }
        }
    }
    return $data_map;
}

//fixed - for exchange rate - if set to 0 - which is unusual
function generateAmountForTotal($data, $currencyWithRate)
{
    $final = 0;
    foreach ($data as $key => $value)
    {
        foreach ($currencyWithRate as $currencyRate)
        {
            if ($currencyRate->id == $value->currency_id)
            {
                if ($value->currency_id != session('default_currency'))
                {
                    if ($currencyRate->rate != 0)
                    {
                        $final += abs($value->total_charge / $currencyRate->rate);
                    }
                    else
                    {
                        // $data_map[$value->day][$value->month] = 0;
                        $final += 0;
                    }
                }
                else
                {
                    $final += abs($value->total_charge);
                }
            }
        }
    }
    return $final;
}

function checkAppMailEnvironment()
{
    return config('paymoney.mail', true);
}

if (!function_exists('isMailEnabled')) {
    /**
     * Check if APP_MAIL=true in .env file.
     *
     * @return bool
     */
    function isMailEnabled()
    {
        return config('paymoney.mail', true);
    }
}

if (!function_exists('isSmsEnabled')) {
    /**
     * Check if APP_SMS=true in .env file.
     *
     * @return bool
     */
    function isSmsEnabled()
    {
        return config('paymoney.sms', true);
    }
}

function checkAppSmsEnvironment()
{
    return config('paymoney.sms', true);
}

function checkDemoEnvironment()
{
    return config('paymoney.demo', true);
}

function getSmsConfigDetails()
{
    return \App\Models\SmsConfig::where(['status' => 'Active'])->first();
}

function sendSMSwithNexmo($nexmoCredentials, $to, $message)
{
    $trimmedMsg = trim(preg_replace('/\s\s+/', ' ', $message));
    $url        = 'https://rest.nexmo.com/sms/json?' . http_build_query([
        'api_key'    => '' . trim($nexmoCredentials['Key']) . '',
        'api_secret' => '' . trim($nexmoCredentials['Secret']) . '',
        'from'       => '' . $nexmoCredentials['default_nexmo_phone_number'] . '',
        'to'         => '' . $to . '',
        'text'       => '' . strip_tags($trimmedMsg) . '',
    ]);
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
}

function sendSMSwithTwilio($twilioCredentials, $to, $message)
{
    $accountSID   = $twilioCredentials['account_sid'];
    $authToken    = $twilioCredentials['auth_token'];
    $twilioNumber = $twilioCredentials['default_twilio_phone_number'];
    $trimmedMsg   = trim(preg_replace('/\s\s+/', ' ', $message));

    $client = new \Twilio\Rest\Client($accountSID, $authToken);
    $client->messages->create(
        $to,
        array(
            'from' => $twilioNumber,
            'body' => strip_tags($trimmedMsg)
        )
    );
}

function sendSMS($to, $message)
{
    $smsConfig = getSmsConfigDetails();
    if (!empty($smsConfig)) {
        $smsCredentials = json_decode($smsConfig->credentials, true);
        if (count($smsCredentials) > 0) {
            if ($smsConfig->type == 'nexmo') {
                sendSMSwithNexmo($smsCredentials, $to, $message);
            }
            elseif ($smsConfig->type == 'twilio') {
                sendSMSwithTwilio($smsCredentials, $to, $message);
            }
        }
    }
}

if (!function_exists('otpCode6')) {
    /**
     * otpCode6
     * @return six digit otp code
     */
    function otpCode6()
    {
        return mt_rand(100000, 999999);
    }
}

function getBrowser($agent)
{
    $browserName = 'Unknown';
    $platform = 'Unknown';
    $version  = "";
    $userBrowser = '';

    if (preg_match('/linux/i', $agent)) {
        $platform = 'linux';
    } elseif (preg_match('/macintosh|mac os x/i', $agent)) {
        $platform = 'mac';
    } elseif (preg_match('/windows|win32/i', $agent)) {
        $platform = 'windows';
    }

    $browsers = [
        'Edg' => 'Microsoft Edge',
        'MSIE' => 'Internet Explorer',
        'Trident' => 'Internet Explorer',
        'Chrome' => 'Google Chrome',
        'Firefox' => 'Mozilla Firefox',
        'Safari' => 'Apple Safari',
        'Opera Mini' => 'Opera Mini',
        'Opera' => 'Opera',
        'Netscape' => 'Netscape'
    ];

    foreach($browsers as $key => $value) {
        if (strpos($agent, $key) !== FALSE) {
            $browserName = $value;
            $userBrowser = $key;
            break;
        }
    }

    // finally get the correct version number
    $known = array('Version', $userBrowser, 'other');
    $pattern = '#(?<browser>' . join('|', $known) . ')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
    if (!preg_match_all($pattern, $agent, $matches)) {
        // we have no matching number just continue
    }

    // see how many we have
    $i = count($matches['browser']);
    if ($i != 1) {
        // we will have two since we are not using 'other' argument yet
        // see if version is before or after the name
        if (strripos($agent, "Version") < strripos($agent, $userBrowser)) {
            $version = $matches['version'][0];
        } else {
            $version = $matches['version'][1];
        }
    } else {
        $version = $matches['version'][0];
    }

    // check if we have a number
    if ($version == null || $version == "") {
        $version = "?";
    }

    return [
        'name'     => $browserName,
        'version'  => $version,
        'platform' => $platform,
    ];
}

function getBrowserFingerprint($user_id, $browser_fingerprint)
{
    $getBrowserFingerprint = App\Models\DeviceLog::where(['user_id' => $user_id, 'browser_fingerprint' => $browser_fingerprint])->first(['browser_fingerprint']);
    return $getBrowserFingerprint;
}

function coinPaymentInfo()
{
    $transInfo = session('transInfo');
    $cpm       = \App\Models\CurrencyPaymentMethod::where(['method_id' => $transInfo['payment_method'], 'currency_id' => $transInfo['currency_id']])->first(['method_data']);
    return json_decode($cpm->method_data);
}

function captchaCheck($enabledCaptcha, $key)
{
    if (isset($enabledCaptcha) && ($enabledCaptcha == 'login' || $enabledCaptcha == 'registration' || $enabledCaptcha == 'login_and_registration')) {
        \Illuminate\Support\Facades\Config::set([(($key == 'site_key') ? 'captcha.sitekey' : 'captcha.secret') => settings($key)]);
    }
}

function getLanguageDefault()
{
    return \App\Models\Language::where(['default' => '1'])->first(['id', 'short_name']);
}

function getDefaultCountry()
{
    $country = \App\Models\Country::where(['is_default' => 'yes'])->first();
    if ($country) {
        return $country->short_name;
    }
    // Fallback: first country by id (e.g. when no default is set in DB)
    $fallback = \App\Models\Country::orderBy('id')->first();
    return $fallback ? $fallback->short_name : '';
}

function phpDefaultTimeZones()
{
    $zones_array = array();
    $timestamp   = time();
    foreach (timezone_identifiers_list() as $key => $zone)
    {
        date_default_timezone_set($zone);
        $zones_array[$key]['zone']          = $zone;
        $zones_array[$key]['diff_from_GMT'] = 'UTC/GMT ' . date('P', $timestamp);
    }
    return $zones_array;
}

function getAuthUserIdentity()
{
    $getAuthUserIdentity = \App\Models\DocumentVerification::where(['user_id' => auth()->user()->id, 'verification_type' => 'identity'])->first(['verification_type', 'status']);
    return $getAuthUserIdentity;
}

function getAuthUserAddress()
{
    $getAuthUserAddress = \App\Models\DocumentVerification::where(['user_id' => auth()->user()->id, 'verification_type' => 'address'])->first(['verification_type', 'status']);
    return $getAuthUserAddress;
}

function allowedDecimalPlaceMessage($decimalPosition)
{
    $message = "*Allowed upto " . $decimalPosition . " decimal places.";
    return $message;
}

function allowedImageDimension($width, $height, $panel = null)
{
    if ($panel == 'user')
    {
        $message = "*" . __('Recommended Dimension') . ": " . $width . " px * " . $height . " px";
    }
    else
    {
        $message = "*Recommended Dimension: " . $width . " px * " . $height . " px";
    }
    return $message;
}

/**
 * [CUSTOM AES-256 ENCRYPTION/DECRYPTION METHOD]
 * param  $action [encrypt/decrypt]
 * param  $string [string]
 */
function initAES256($action, $plaintext)
{
    $output   = '';
    $cipher   = "AES-256-CBC";
    $password = 'K8m26hzj22TtZxnzX96vmRAVTzPxNXRB';
    $key      = substr(hash('sha256', $password, true), 0, 32); // Must be exact 32 chars (256 bit)
                                                                // $ivlen    = openssl_cipher_iv_length($cipher);
                                                                // $iv       = openssl_random_pseudo_bytes($ivlen); // IV must be exact 16 chars (128 bit)
    $secretIv = 'UP4n2cr8Bwn83X4h';
    $iv       = substr(hash('sha256', $secretIv), 0, 16);
    if ($plaintext != '')
    {
        if ($action == 'encrypt')
        {
            $output = base64_encode(openssl_encrypt($plaintext, $cipher, $key, OPENSSL_RAW_DATA, $iv));
        }
        if ($action == 'decrypt')
        {
            $output = openssl_decrypt(base64_decode($plaintext), $cipher, $key, OPENSSL_RAW_DATA, $iv);
        }
    }
    return $output;
}

function getFormatedCurrencyList($rates, $rateAmount)
{
    foreach ($rates as $coin => $coinDetails) {
        if ((INT) $coinDetails['is_fiat'] === 0) {
            if ($rates[$coin]['rate_btc'] != 0) {
                $rate = ($rateAmount / $rates[$coin]['rate_btc']);
            }
            else {
                $rate = $rateAmount;
            }
            $coins[] = [
                'name'     => $coinDetails['name'],
                'rate'     => number_format($rate, 8, '.', ''),
                'iso'      => $coin,
                'icon'     => 'https://www.coinpayments.net/images/coins/' . $coin . '.png',
                'selected' => $coin == 'BTC' ? true : false,
                'accepted' => $coinDetails['accepted'],
            ];
            $aliases[$coin] = $coinDetails['name'];
        }

        if ((INT) $coinDetails['is_fiat'] === 0 && $coinDetails['accepted'] == 1) {
            $renamedCoin = explode('.', $coin);

            $rate           = ($rateAmount / $rates[$coin]['rate_btc']);
            $coins_accept[] = [
                'name'     => $coinDetails['name'],
                'rate'     => number_format($rate, 8, '.', ''),
                'iso'      => $coin,
                'icon'     => 'https://www.coinpayments.net/images/coins/' . ((count($renamedCoin) > 1) ? $renamedCoin[0] : $coin)  . '.png',
                'selected' => $coin == 'BTC' ? true : false,
                'accepted' => $coinDetails['accepted'],
            ];
        }

        if ((INT) $coinDetails['is_fiat'] === 1) {
            $fiat[$coin] = $coinDetails;
        }
    }

    return ['coins' => $coins, 'coins_accept' => $coins_accept, 'fiat' => $fiat, 'aliases' => $aliases];
}
/**
 * [CUSTOM AES-256 ENCRYPTION/DECRYPTION METHOD]
 * param  $action [encrypt/decrypt]
 * param  $string [string]
 */
function convert_string($action, $string) {
    $output         = '';
    $encrypt_method = "AES-256-CBC";
    $secret_key     = 'XXD93D945143F656DD9094450F802743F5457551991C8CXX';
    $secret_iv      = 'XXE8327B11DA84769CB73FE4495C63XX';
    // hash
    $key                   = hash('sha256', $secret_key);
    $initialization_vector = substr(hash('sha256', $secret_iv), 0, 16);
    if ($string != '') {
        if ($action == 'encrypt') {
            $output = openssl_encrypt($string, $encrypt_method, $key, 0, $initialization_vector);
            $output = base64_encode($output);
        } if ($action == 'decrypt') {
            $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $initialization_vector);
        }
    }
    return $output;
}

if (!function_exists('getStatuses')) {

    /**
     * Return status, class, colors
     *
     * @return string
     */
    function getStatuses()
    {
        return [
            'success' => ['text' => __('Success'), 'label' => 'success', 'color' => 'green'],
            'pending' => ['text' => __('Pending'), 'label' => 'primary', 'color' => 'blue'],
            'exchanger paid' => ['text' => __('Exchanger Paid'), 'label' => 'primary', 'color' => 'blue'],
            'creator paid' => ['text' => __('Creator Paid'), 'label' => 'primary', 'color' => 'blue'],
            'refund' => ['text' => __('Refunded'), 'label' => 'warning', 'color' => 'orange'],
            'blocked' => ['text' => __('Cancelled'), 'label' => 'danger', 'color' => 'red'],
            'active' => ['text' => __('Active'), 'label' => 'success', 'color' => 'green'],
            'inactive' => ['text' => __('Inactive'), 'label' => 'danger', 'color' => 'red'],
            'expired' => ['text' => __('Expired'), 'label' => 'danger', 'color' => 'red'],
            'suspended' => ['text' => __('Suspended'), 'label' => 'warning', 'color' => 'orange'],
            'open' => ['text' => __('Open'), 'label' => 'success', 'color' => 'green'],
            'in progress' => ['text' => __('In Progress'), 'label' => 'primary', 'color' => 'blue'],
            'hold' => ['text' => __('Hold'), 'label' => 'warning', 'color' => 'orange'],
            'closed' => ['text' => __('Closed'), 'label' => 'danger', 'color' => 'red'],
            'approved' => ['text' => __('Approved'), 'label' => 'success', 'color' => 'green'],
            'rejected' => ['text' => __('Rejected'), 'label' => 'danger', 'color' => 'red'],
            'declined' => ['text' => __('Declined'), 'label' => 'danger', 'color' => 'red'],
            'solve' => ['text' => __('Solved'), 'label' => 'success', 'color' => 'green'],
            'moderation' => ['text' => __('Moderation'), 'label' => 'primary', 'color' => 'blue'],
            'disapproved' => ['text' => __('Disapproved'), 'label' => 'danger', 'color' => 'red'],
            'draft' => ['text' => __('Draft'), 'label' => 'default', 'color' => 'default'],
            'cancelled' => ['text' => __('Cancelled'), 'label' => 'danger', 'color' => 'red'],
            'completed' => ['text' => __('Completed'), 'label' => 'info', 'color' => 'blue'],
            'terminated' => ['text' => __('Terminated'), 'label' => 'danger', 'color' => 'red'],
            'freezed' => ['text' => __('Freezed'), 'label' => 'primary', 'color' => 'blue'],
            'expired' => ['text' => __('Expired'), 'label' => 'danger', 'color' => 'red'],
            'invited' => ['text' => __('Invited'), 'label' => 'warning', 'color' => 'orange'],
        ];
    }
}

if (!function_exists('getStatus')) {

    /**
     * Get transactions status by HTML Lable
     *
     * @param string $status
     *
     * @return HTMLString
     */
    function getStatus($status = null)
    {
        if (empty($status)) {
            return '';
        }
        $statuses = getStatuses();

        $status = strtolower($status);
        return $statuses[$status]['text'];
    }
}

if (!function_exists('getStatusLabel')) {

    /**
     * Get transactions status by HTML Lable
     *
     * @param string $status
     *
     * @return HTMLString
     */
    function getStatusLabel($status = null)
    {
        if (empty($status)) {
            return '';
        }
        $statuses = getStatuses();

        $status = strtolower($status);
        return '<span class="label label-' . $statuses[$status]['label'] . '">' . $statuses[$status]['text'] . '</span>';
    }
}

if (!function_exists('getStatusBadge')) {

    /**
     * Get transactions status by HTML Lable
     *
     * @param string $status
     *
     * @return HTMLString
     */
    function getStatusBadge($status = null)
    {
        if (empty($status)) {
            return '';
        }
        $statuses = getStatuses();

        $status = strtolower($status);
        return '<span class="badge badge-' . $statuses[$status]['label'] . '">' . $statuses[$status]['text'] . '</span>';
    }
}

if (!function_exists('getStatusText')) {

    /**
     * Get transactions status by HTML text
     *
     * @param string $status
     *
     * @return HTMLString
     */
    function getStatusText($status = null)
    {
        if (empty($status)) {
            return '';
        }
        $statuses = getStatuses();

        $status = strtolower($status);
        return '<span class="text text-' . $statuses[$status]['color'] . '">' . $statuses[$status]['text'] . '</span>';
    }
}

if (!function_exists('getStatusInputLabel')) {

    /**
     * Transaction edit sender-receiver Title Text
     *
     * @param string $type [TransactionTypeId like Deposit, Withdrawal]
     * @param string $userType [user - receiver]
     *
     * @return HtmlString
     */
    function getStatusInputLabel($type = null, $userType = null)
    {
        if (empty($type) || empty($userType)) {
            return '';
        }

        $transactionTypes = [
            getTransactionTypeId('Deposit') => ['user' => 'User', 'receiver' => 'Receiver'],
            getTransactionTypeId('Exchange_From') => ['user' => 'User', 'receiver' => 'Receiver'],
            getTransactionTypeId('Exchange_To') => ['user' => 'User', 'receiver' => 'Receiver'],
            getTransactionTypeId('Withdrawal') => ['user' => 'User', 'receiver' => 'Receiver'],
            getTransactionTypeId('Payment_Sent') => ['user' => 'User', 'receiver' => 'Receiver'],
            getTransactionTypeId('Payment_Received') => ['user' => 'User', 'receiver' => 'Receiver'],
            getTransactionTypeId('Transferred') => ['user' => 'Paid By', 'receiver' => 'Paid To'],
            getTransactionTypeId('Received') => ['user' => 'Paid By', 'receiver' => 'Paid To'],
            getTransactionTypeId('Request_Sent') => ['user' => 'Request From', 'receiver' => 'Request To'],
            getTransactionTypeId('Request_Received') => ['user' => 'Request From', 'receiver' => 'Request To']
        ];

        return '<label class="control-label col-sm-3 fw-bold text-end" for="'. $userType .'">' . ($transactionTypes[$type][$userType] ?? '') . '</label>';
    }
}

if (! function_exists('getPaymoneySettings')) {

    /**
     * Get Paymoney configurations info
     *
     * @param string $type
     *
     * @return array
     */
    function getPaymoneySettings($type = null)
    {
        if (empty($type)) {
            return false;
        }
        $array = [
            'transaction_types' => [
                'web' => [
                    'sent' => [
                        getTransactionTypeId('Deposit'),
                        getTransactionTypeId('Transferred'),
                        getTransactionTypeId('Exchange_From'),
                        getTransactionTypeId('Exchange_To'),
                        getTransactionTypeId('Request_Sent'),
                        getTransactionTypeId('Withdrawal'),
                        getTransactionTypeId('Payment_Sent')
                    ],
                    'received' => [
                        getTransactionTypeId('Received'),
                        getTransactionTypeId('Request_Received'),
                        getTransactionTypeId('Payment_Received')
                    ]
                ],
                'mobile' => [
                    'sent' => [
                        'Deposit' => getTransactionTypeId('Deposit'),
                        'Transferred' => getTransactionTypeId('Transferred'),
                        'Exchange_From' => getTransactionTypeId('Exchange_From'),
                        'Exchange_To' => getTransactionTypeId('Exchange_To'),
                        'Request_Sent' => getTransactionTypeId('Request_Sent'),
                        'Withdrawal' => getTransactionTypeId('Withdrawal'),
                        'Payment_Sent' => getTransactionTypeId('Payment_Sent')
                    ],
                    'received' => [
                        'Received' => getTransactionTypeId('Received'),
                        'Request_Received' => getTransactionTypeId('Request_Received'),
                        'Payment_Received' => getTransactionTypeId('Payment_Received')
                    ]
                ],
                'payment_sent' => [],
                'payment_received' => []

            ],
            'payment_methods' => [
                'web' => [
                    'all' => [
                        getPaymentMethodId('Mts'),
                        getPaymentMethodId('Stripe'),
                        getPaymentMethodId('Paypal'),
                        getPaymentMethodId('PayUmoney'),
                        getPaymentMethodId('Bank'),
                        getPaymentMethodId('Coinpayments'),
                        getPaymentMethodId('Payeer'),
                        getPaymentMethodId('Crypto'),
                        getPaymentMethodId('Coinbase')
                    ],
                    'deposit' => [
                        getPaymentMethodId('Mts'),
                        getPaymentMethodId('Stripe'),
                        getPaymentMethodId('Paypal'),
                        getPaymentMethodId('PayUmoney'),
                        getPaymentMethodId('Bank'),
                        getPaymentMethodId('Coinpayments'),
                        getPaymentMethodId('Payeer'),
                        getPaymentMethodId('Coinbase')
                    ],
                    'withdrawal' => [
                        getPaymentMethodId('Paypal'),
                        getPaymentMethodId('Bank'),
                        getPaymentMethodId('Crypto')
                    ],
                    'fiat' => [
                        'deposit' => [
                            getPaymentMethodId('Mts'),
                            getPaymentMethodId('Stripe'),
                            getPaymentMethodId('Paypal'),
                            getPaymentMethodId('PayUmoney'),
                            getPaymentMethodId('Bank'),
                            getPaymentMethodId('Coinpayments'),
                            getPaymentMethodId('Payeer'),
                            getPaymentMethodId('Coinbase'),
                            getPaymentMethodId('Flutterwave')
                        ],
                        'withdrawal' => [
                            getPaymentMethodId('Mts'),
                            getPaymentMethodId('Paypal'),
                            getPaymentMethodId('Bank')
                        ],
                    ],
                    'crypto' => [
                        'deposit' => [
                            getPaymentMethodId('Mts'),
                            getPaymentMethodId('Coinpayments'),
                            getPaymentMethodId('Coinbase')
                        ],
                        'withdrawal' => [
                            getPaymentMethodId('Mts'),
                            getPaymentMethodId('Crypto')
                        ],
                    ]
                ],
                'mobile' => [
                    'all' => [
                        'Stripe' => getPaymentMethodId('Stripe'),
                        'Paypal' => getPaymentMethodId('Paypal'),
                        'Bank' => getPaymentMethodId('Bank'),
                        'Coinpayments' => getPaymentMethodId('Coinpayments'),
                        'Crypto' => getPaymentMethodId('Crypto'),
                        'Coinbase' => getPaymentMethodId('Coinbase')
                    ],
                    'deposit' => [
                        'Stripe' => getPaymentMethodId('Stripe'),
                        'Paypal' => getPaymentMethodId('Paypal'),
                        'Bank' => getPaymentMethodId('Bank'),
                        'Coinpayments' => getPaymentMethodId('Coinpayments'),
                        'Coinbase' => getPaymentMethodId('Coinbase')
                    ],
                    'withdrawal' => [
                        'Paypal' => getPaymentMethodId('Paypal'),
                        'Bank' => getPaymentMethodId('Bank'),
                        'Crypto' => getPaymentMethodId('Crypto')
                    ],
                    'fiat' => [
                        'deposit' => [
                            'Stripe' => getPaymentMethodId('Stripe'),
                            'Paypal' => getPaymentMethodId('Paypal'),
                            'Bank' => getPaymentMethodId('Bank'),
                            'Coinbase' => getPaymentMethodId('Coinbase'),
                            'Coinpayments' => getPaymentMethodId('Coinpayments'),
                            'Flutterwave' => getPaymentMethodId('Flutterwave')
                        ],
                        'withdrawal' => [
                            'Paypal' => getPaymentMethodId('Paypal'),
                            'Bank' => getPaymentMethodId('Bank')
                        ],
                    ],
                    'crypto' => [
                        'deposit' => [
                            'Coinpayments' => getPaymentMethodId('Coinpayments'),
                            'Coinbase' => getPaymentMethodId('Coinbase')
                        ],
                        'withdrawal' => [
                            'Crypto' => getPaymentMethodId('Crypto')
                        ],
                    ]
                ]
            ]
        ];

        // Module Transaction Types
        $modules = getAllModules();
        foreach ($modules as $module) {
            if (!empty(config($module->get('alias') . '.transaction_type_settings'))) {
                // Web
                $array['transaction_types']['web']['sent'] = array_merge($array['transaction_types']['web']['sent'], config($module->get('alias') . '.transaction_type_settings')['web']['sent']);
                $array['transaction_types']['web']['received'] = array_merge($array['transaction_types']['web']['received'], config($module->get('alias') . '.transaction_type_settings')['web']['received']);

                // Mobile
                $array['transaction_types']['mobile']['sent'] = array_merge($array['transaction_types']['mobile']['sent'], config($module->get('alias') . '.transaction_type_settings')['mobile']['sent']);
                $array['transaction_types']['mobile']['received'] = array_merge($array['transaction_types']['mobile']['received'], config($module->get('alias') . '.transaction_type_settings')['mobile']['received']);

                if (!empty(config($module->get('alias') . '.transaction_type_settings')['payment_sent'])) {
                    $array['transaction_types']['payment_sent'] = array_merge($array['transaction_types']['payment_sent'], config($module->get('alias') . '.transaction_type_settings')['payment_sent']);
                }

                if (!empty(config($module->get('alias') . '.transaction_type_settings')['payment_received'])) {
                    $array['transaction_types']['payment_received'] = array_merge($array['transaction_types']['payment_received'], config($module->get('alias') . '.transaction_type_settings')['payment_received']);
                } 
            }
        }

        // Mobile MOney - Payment method
        if (config('mobilemoney.is_active')) {
            $mobileMoneyId = getPaymentMethodId('MobileMoney');
            if ($mobileMoneyId) {
                $array['payment_methods']['web']['all'][] = $mobileMoneyId;
                $array['payment_methods']['web']['deposit'][] = $mobileMoneyId;
                $array['payment_methods']['web']['withdrawal'][] = $mobileMoneyId;
                $array['payment_methods']['web']['fiat']['deposit'][] = $mobileMoneyId;
                $array['payment_methods']['web']['fiat']['withdrawal'][] = $mobileMoneyId;
            }
        }

        // Transaction Types
        $array['transaction_types']['web']['all'] = array_merge($array['transaction_types']['web']['sent'], $array['transaction_types']['web']['received']);
        $array['transaction_types']['mobile']['all'] = array_merge($array['transaction_types']['mobile']['sent'], $array['transaction_types']['mobile']['received']);

        return $array[$type];
    }
}

if (!function_exists('preference')) {

    /**
     * Get preference values
     *
     * @param string $field [return specific value]
     * @param string $default [take default value as optional if not provide]
     *
     * @return void
     */
    function preference($field = null, $default = null)
    {
        $preference = new App\Models\Preference();

        if (is_null($field)) {
            return $preference->getAll()->pluck('value', 'field')->toArray();
        }

        $value = $default;
        $preferences = $preference->getAll()->pluck('value', 'field')->toArray();

        if (array_key_exists($field, $preferences)) {
            $value = $preferences[$field];
        }

        return $value;
    }
}

if (!function_exists('settings')) {

    /**
     * Get settings values
     *
     * @param string $field [return specific value, if don't match provide type values]
     *
     * @return string
     * @return array
     */
    function settings($field = null)
    {
        $setting = new App\Models\Setting();

        if (is_null($field)) {
            return $setting->getAll()->pluck('value', 'name')->toArray();
        }

        $settings = $setting->getAll()->pluck('value', 'name')->toArray();

        if (array_key_exists($field, $settings)) {
            $result = $settings[$field];
        } else {
            $result = $setting->getAll()->where('type', $field)->pluck('value', 'name')->toArray();
        }

        return $result;
    }
}

if (!function_exists('isDefault')) {

    /**
     * Get is_default status by HTML Label
     *
     * @param string $status
     *
     * @return HTMLString
     */
    function isDefault($status = null)
    {
        if (empty($status)) {
            return '';
        }
        $statuses = [
            'yes' => ['text' => __('Yes'), 'label' => 'success', 'color' => 'green'],
            'no' => ['text' => __('No'), 'label' => 'danger', 'color' => 'red']
        ];

        $status = strtolower($status);
        return '<span class="label label-' . $statuses[$status]['label'] . '">' . $statuses[$status]['text'] . '</span>';
    }
}

function dataTableOptions(array $options = [])
{
    $default = [
        'order' => [[0, 'desc']],
        'pageLength' => preference('row_per_page'),
        'language' => preference('language'),
    ];

    return array_merge($default, $options);
}

if (!function_exists('templateHeaderText')) {

    /**
     * Get Email or sms template header text
     *
     * @param string $heading
     *
     * @return String
     */
    function templateHeaderText($heading)
    {
        $heading = str_replace('!', '', $heading);

        if (str_contains($heading, 'Notice of ')) {
            $heading = str_replace('Notice of ', '', $heading);
        } else if (str_contains($heading, 'Notice for')) {
            $heading = str_replace('Notice for ', '', $heading);
        } else if (str_contains($heading, 'Notice to')) {
            $heading = str_replace('Notice to ', '', $heading);
        }

        return __('Compose :x Template', ['x' => $heading]);
    }
}

if (!function_exists('n_as_k_c')) {
    function n_as_k_c() {
        if(!g_e_v()) {
            return true;
        }
        if(!g_c_v()) {
            try {
                $d_ = g_d();
                $e_ = g_e_v();
                $e_ = explode('.', $e_);
                $c_ = md5($d_ . $e_[1]);
                if($e_[0] == $c_) {
                    p_c_v();
                    return false;
                } else {
                    return true;
                }
            } catch(\Exception $e) {
                return true;
            }
        }
        return false;
    }

}

if (!function_exists('xss_clean')) {

    function xss_clean($data)
    {
        if (is_array($data)) {
            // Recursively sanitize array values
            return array_map('xss_clean', $data);
        }

        if (!is_string($data)) {
            return $data; // Return as-is if not a string
        }

        // Fix &entity\n;
        $data = str_replace(['&amp;', '&lt;', '&gt;'], ['&amp;amp;', '&amp;lt;', '&amp;gt;'], $data);
        $data = preg_replace('/(&#*\w+)[\x00-\x20]+;/u', '$1;', $data);
        $data = preg_replace('/(&#x*[0-9A-F]+);*/iu', '$1;', $data);
        $data = html_entity_decode($data, ENT_COMPAT, 'UTF-8');

        // Remove any attribute starting with "on" or xmlns
        $data = preg_replace('#(<[^>]+?[\x00-\x20"\'])(?:on|xmlns)[^>]*+>#iu', '$1>', $data);

        // Remove javascript: and vbscript: protocols
        $data = preg_replace('#([a-z]*)[\x00-\x20]*=[\x00-\x20]*([`\'"]*)[\x00-\x20]*j[\x00-\x20]*a[\x00-\x20]*v[\x00-\x20]*a[\x00-\x20]*s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:#iu', '$1=$2nojavascript...', $data);
        $data = preg_replace('#([a-z]*)[\x00-\x20]*=([\'"]*)[\x00-\x20]*v[\x00-\x20]*b[\x00-\x20]*s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:#iu', '$1=$2novbscript...', $data);
        $data = preg_replace('#([a-z]*)[\x00-\x20]*=([\'"]*)[\x00-\x20]*-moz-binding[\x00-\x20]*:#u', '$1=$2nomozbinding...', $data);

        // Only works in IE: <span style="width: expression(alert('Ping!'));"></span>
        $data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?expression[\x00-\x20]*\([^>]*+>#i', '$1>', $data);
        $data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?behaviour[\x00-\x20]*\([^>]*+>#i', '$1>', $data);
        $data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:*[^>]*+>#iu', '$1>', $data);

        // Remove namespaced elements (we do not need them)
        $data = preg_replace('#</*\w+:\w[^>]*+>#i', '', $data);

        do {
            // Remove really unwanted tags
            $old_data = $data;
            $data = preg_replace('#</*(?:applet|b(?:ase|gsound|link)|embed|frame(?:set)?|i(?:frame|layer)|l(?:ayer|ink)|meta|object|s(?:cript|tyle)|title|xml)[^>]*+>#i', '', $data);
        } while ($old_data !== $data);

        return $data;
    }
}

if (!function_exists('stripBeforeSave')) {
    /**
     * stripBeforeSave method
     * This function strips or skips HTML tags
     *
     * @param string $string [The text that will be stripped]
     * @param array $options
     *
     * @return string
     */
    function stripBeforeSave($string = null, $options = ['skipAllTags' => true, 'mergeTags' => false])
    {
        $finalString = [];
        if ($options['skipAllTags'] === false) {
            $allow = '<h1><h2><h3><h4><h5><h6><p><b><br><hr><i><pre><small><strike><strong><sub><sup><time><u><form><input><textarea><button><select><option><label><frame><iframe><img><audio><video><a><link><nav><ul><ol><li><table><th><tr><td><thead><tbody><div><span><header><footer><main><section><article>';
            if (isset($options['mergeTags']) && $options['mergeTags'] === true && isset($options['allowedTags'])) {
                $allow .= is_array($options['allowedTags']) ? implode('', $options['allowedTags']) : trim($options['allowedTags']);
            } else {
                $allow = isset($options['allowedTags']) && is_array($options['allowedTags']) ? implode('', $options['allowedTags']) : trim($options['allowedTags']);
            }
            if (is_array($string)) {
                foreach ($string as $key => $value) {
                    $finalString[$key] = strip_tags($value, $allow);
                }
            } else {
                $finalString = strip_tags($string, $allow);
            }
        } else {
            if (is_array($string)) {
                foreach ($string as $key => $value) {
                    $finalString[$key] = strip_tags($value);
                }
            } else {
                $finalString = strip_tags($string);
            }
        }
        return !empty($finalString) ? $finalString : null;
    }
}

if (!function_exists('getTransactionTypes')) {

    function getTransactionTypes($type = null)
    {
        $transactionTypes = [];

        $transactionId = array_merge(getPaymoneySettings('transaction_types')['payment_sent'], getPaymoneySettings('transaction_types')['payment_received']);

        $fetchTransctionTypes =  \App\Models\TransactionType::whereNotIn('id', $transactionId)->get();
        foreach ($fetchTransctionTypes as $value) {
            $transactionTypes[strtolower($value->name)] = $value->name;
        }

        if ($type) {
            return $transactionTypes[$type];
        }

        return $transactionTypes;
    }
}

if (!function_exists('getColumnValue')) {

    function getColumnValue($object, $columnOne = 'first_name', $columnTwo = 'last_name', $emptyReturn = '-')
    {
        $name = [];
        if (optional($object)->{$columnOne}) {
            $name[] = $object->{$columnOne};
        }
        if (optional($object)->{$columnTwo}) {
            $name[] = $object->{$columnTwo};
        }

        return count($name) ? implode(' ', $name) : $emptyReturn;
    }
}

if (!function_exists('getStripeMonths')) {

    function getStripeMonths()
    {
        $number = range(1, 12);
        $data = [];
        foreach ($number as $num) {
            $value = sprintf('%02d', $num);

            $data[] = '<option value="' . $value . '">' . $value . '</option>';
        }

        return implode(' ', $data);
    }
}

if (!function_exists('currencyTransactionTypes')) {
    function currencyTransactionTypes($transactionType)
    {
        $activateFor = [];
        $transactionType = request()->ajax() ? json_decode($transactionType) : $transactionType;
        if (!empty($transactionType)) {
            foreach ($transactionType as $key => $value) {
                $activateFor[$value] = '';
            }
        } else {
            $activateFor = ['' => ''];
        }

        return $activateFor;
    }
}


if (!function_exists('miniCollection')) {

    /**
     * Returns a new \App\Lib\MiniCollection object
     * @param array $hayStack optional
     * @return \App\Lib\MiniCollection;
     */
    function miniCollection($hayStack = [], $nested = false)
    {
        return new \App\Http\Helpers\MiniCollection($hayStack, $nested);
    }
}

if (!function_exists('getColor')) {
    /**
     * getColor
     *
     * @param  mixed $status
     * @return string
     */
    function getColor($status): string
    {
        switch ($status) {
            case 'Success':
            case 'Approved':
            case 'Open':
            case 'Solve':
            case 'Active':
                return 'text-success';
                break;
            case 'Pending':
            case 'Moderation':
            case 'Refunded':
            case 'Refund':
            case 'Freezed':
                return 'text-warning';
                break;
            case 'Cancelled':
            case 'Disapproved':
            case 'Closed':
            case 'Blocked':
            case 'Rejected':
            case 'Terminated':
            case 'Inactive':
            case 'Declined':
            case 'Expired':
                return 'text-danger';
                break;
            case 'Exchanger Paid':
            case 'Creator Paid':
            case 'Completed':
                return 'text-primary';
                break;

            default:
                return '5E';
                break;
        }
    }
}

if (!function_exists('getBgColor')) {
    /**
     * getColor
     *
     * @param  mixed $status
     * @return string
     */
    function getBgColor($status): string
    {
        switch (ucfirst($status)) {
            case 'Moderation':
            case 'Pending':
            case 'Inactive':
            case 'Hold':
            case 'Freezed':
                return 'warning';
                break;
            case 'Closed':
            case 'Disapproved':
            case 'Cancelled':
            case 'Inactive':
            case 'Terminated':
            case 'Blocked':
            case 'Rejected':
            case 'Expired':
                return 'danger';
                break;
            case 'Approved':
            case 'Active':
            case 'Open':
            case 'Solved':
                return 'success';
                break;
            case 'In Progress':
            case 'Completed':
            case 'Exchanger Paid':
            case 'Creator Paid':
                return 'primary';
                break;
            default:
                return 'A5E';
                break;
        }
    }
}

function cryptoApiLogDetails($transaction)
{
    if (!empty($transaction->cryptoAssetApiLog)) {
        $getCryptoDetails = getCryptoPayloadConfirmationsDetails($transaction->transaction_type_id, $transaction->cryptoAssetApiLog->payload, $transaction->cryptoAssetApiLog->confirmations);
        if (count($getCryptoDetails) > 0)  {
            if (isset($getCryptoDetails['senderAddress'])) {
                $data['senderAddress'] = $getCryptoDetails['senderAddress'];
            }
            if (isset($getCryptoDetails['receiverAddress'])) {
                $data['receiverAddress'] = $getCryptoDetails['receiverAddress'];
            }
            $data['network'] = isset($getCryptoDetails['network']) ? $getCryptoDetails['network'] : null;
            $data['network_fee'] = isset($getCryptoDetails['network_fee']) ? formatNumber($getCryptoDetails['network_fee'], $transaction->currency_id) : 0.00000000;

            $data['confirmations'] = $getCryptoDetails['confirmations'];

            return $data;
        }
    }
}

if (!function_exists('getTransactionInfo')) {
    /**
     * getTransactionInfo
     *
     * @param  mixed $type
     * @return array
     */
    function getTransactionInfo($type, $transaction = null): array
    {
        switch ($type) {
            case 'Deposit':
                return [
                    'name' => 'Deposited',
                    'type' => 'Deposited By',
                    'user' => getColumnValue($transaction?->user),
                    'currency' => 'Currency',
                    'print' => 'user.deposit.print'
                ];
                break;
            case 'Withdrawal':
                return [
                    'name' => 'Withdrawal',
                    'type' => 'Withdrawal By',
                    'user' => getColumnValue($transaction?->user),
                    'currency' => 'Currency',
                    'print' => 'user.withdrawal.print'
                ];
                break;
            case 'Transferred':
                return [
                    'name' => 'Transferred',
                    'type' => 'Transferred To',
                    'user' => ($transaction?->user_type == 'unregistered') ? (($transaction?->email) ? $transaction?->email : $transaction?->phone) : getColumnValue($transaction?->end_user),
                    'currency' => 'Currency',
                    'print' => 'user.send_money.print'

                ];
                break;
            case 'Received':
                return [
                    'name' => 'Received',
                    'type' => 'Received From',
                    'user' => getColumnValue($transaction?->end_user),
                    'currency' => 'Currency',
                    'print' => 'user.send_money.print'
                ];
                break;
            case 'Exchange_From':
                return [
                    'name' => 'Exchanged',
                    'type' => 'Exchanged By',
                    'user' => getColumnValue($transaction?->user),
                    'currency' => 'Exchanged From',
                    'print' => 'user.exchange_transaction.print'
                ];
                break;
            case 'Exchange_To':
                return [
                    'name' => 'Exchanged',
                    'type' => 'Exchanged By',
                    'user' => getColumnValue($transaction?->user),
                    'currency' => 'Exchanged To',
                    'print' => 'user.exchange_transaction.print'
                ];
                break;
            case 'Request_Sent':
                return [
                    'name' => 'Requested',
                    'type' => 'Requested To',
                    'user' => ($transaction?->user_type == 'unregistered') ? (($transaction?->email) ? $transaction?->email : $transaction?->phone) : getColumnValue($transaction?->end_user),
                    'currency' => 'Currency',
                    'print' => 'user.request_money.print'
                ];
                break;
            case 'Request_Received':
                return [
                    'name' => 'Requested',
                    'type' => 'Requested From',
                    'user' => getColumnValue($transaction?->end_user),
                    'currency' => 'Currency',
                    'print' => 'user.request_money.print'
                ];
                break;
            case 'Payment_Sent':
                return [
                    'name' => 'Payment',
                    'type' => 'Business Name',
                    'user' => $transaction?->merchant?->business_name,
                    'currency' => 'Currency',
                    'print' => 'user.merchant_payment.print'
                ];
                break;
            case 'Payment_Received':
                return [
                    'name' => 'Payment',
                    'type' => 'Payment By',
                    'user' => getColumnValue($transaction?->end_user),
                    'currency' => 'Currency',
                    'print' => 'user.merchant_payment.print'
                ];
                break;
            case 'Crypto_Sent':
                return [
                    'name' => 'Crypto Sent',
                    'type' => 'Receiver',
                    'user' => getColumnValue($transaction?->end_user),
                    'currency' => 'Currency',
                    'print' => 'user.crypto_send_receive.print'
                ];
                break;
            case 'Crypto_Received':
                return [
                    'name' => 'Received',
                    'type' => 'Sender',
                    'user' => getColumnValue($transaction?->end_user),
                    'currency' => 'Currency',
                    'print' => 'user.crypto_send_receive.print'
                ];
                break;
            case 'Token_Sent':
                return [
                    'name' => 'Token Sent',
                    'type' => 'Receiver',
                    'user' => getColumnValue($transaction?->end_user),
                    'currency' => 'Currency',
                    'print' => 'user.token_send_receive.print'
                ];
                break;
            case 'Token_Received':
                return [
                    'name' => 'Token Received',
                    'type' => 'Sender',
                    'user' => getColumnValue($transaction?->end_user),
                    'currency' => 'Currency',
                    'print' => 'user.token_send_receive.print'
                ];
                break;

            case 'Referral_Award':
                return [
                    'name' => 'Award',
                    'type' => 'Awarded User',
                    'user' => getColumnValue($transaction?->user),
                    'currency' => 'Currency',
                    'print' => 'user.transactions.referral_award_print'
                ];
                break;

            default:
                return [
                    'name' => 'Transaction',
                    'type' => 'Transaction By',
                    'user' => getColumnValue($transaction?->user),
                    'currency' => 'Currency',
                    'print' => 'user.transactions.print'
                ];
                break;
        }
    }
}

if (!function_exists('getTransactionPaymentMethod')) {
    /**
     * getTransactionPaymentMethod
     *
     * @param  mixed $methodName
     * @return string
     */
    function getTransactionPaymentMethod(?string $methodName): ?string
    {
        return ('Mts' == $methodName) ? settings('name') : $methodName;
    }
}

if (!function_exists('generateQrcode')) {
    /**
     * generateQrcode
     *
     * @param  mixed $secret
     * @param  mixed $size
     * @return void
     */
    function generateQrcode(string $secret, string $size = '200x200')
    {
        return !empty($secret) ? 'https://api.qrserver.com/v1/create-qr-code/?data='. $secret .'&size='. $size : '';
    }
}

if (! function_exists('payment_option')) {
    /**
     * payment_option
     *
     * @param  mixed $method
     * @return void
     */
    function payment_option($method)
    {
        $attributes = [
            'data-obj' => json_encode($method->getAttributes()),
            'value' => $method->id,
            'data-type' => $method->type,
        ];

        switch ($method->type) {
            case getPaymentMethodId('Paypal'):
                $text = $method->paymentMethod->name . ' (' . $method->email . ')';
                break;
            case getPaymentMethodId('Bank'):
                $text = $method->paymentMethod->name . ' (' . $method->account_name . ')';
                break;
            case getPaymentMethodId('Crypto'):
                $text = $method->paymentMethod->name . ' (' . $method->currency->code . ' - ' . $method->crypto_address . ')';
                break;
            case getPaymentMethodId('MobileMoney'):
                if (config('mobilemoney.is_active')) {
                    $text = $method->paymentMethod->name . ' (' . ($method->mobilemoney->mobilemoney_name ?? '') . ' ****' . substr($method->mobile_number, -4) . ')';
                } else {
                    $text = $method->paymentMethod->name . ' (' . $method->account_number . ')';
                }
                break;
            default:
                $text = $method->paymentMethod->name . ' (' . $method->account_number . ')';
                break;
        }

        $attributes_str = implode(' ', array_map(function ($key, $value) {
            return $key . '="' . htmlspecialchars($value) . '"';
        }, array_keys($attributes), $attributes));

        $isSelected = '';

        if (old('withdrawal_method_id') && old('withdrawal_method_id') == $method->id) {
            $isSelected = 'selected="selected"';
        } elseif (!empty(session('withdrawalData')) && session('withdrawalData')['withdrawal_method_id'] == $method->id) {
            $isSelected = 'selected="selected"';
        }

        return '<option ' . $attributes_str. $isSelected . '>' . htmlspecialchars($text) . '</option>';
    }
}

if (! function_exists('getPaymentDetails')) {
    /**
     * getPaymentDetails
     *
     * @param  mixed $payout
     * @return void
     */
    function getPaymentDetails($payout)
    {
        if ($payout->payment_method->name == "Bank") {
            if ($payout->withdrawal_detail) {
                return $payout->withdrawal_detail->account_name;
            } else {
                return '-';
            }
        } elseif ($payout->payment_method->name == "Mts") {
            return settings('name');
        } else {
            return $payout->payment_method_info;
        }
    }
}

if (!function_exists('generateOptions')) {
    /**
     * Return all options
     *
     * @param array $options
     * @param null $selected
     * @param bool $optionKey
     * @param string $extraAttr
     *
     * @return string
     */
    function generateOptions($options = [], $selected = null, $optionKey = false, $extraAttr = '')
    {
        if (empty($options)) {
            return '';
        }

        $data = [];
        foreach ($options as $key => $value) {
            $val = $optionKey ? $key : $value;

            if (is_array($selected)) {
                $data[] = '<option ' . $extraAttr . ' value="' . $val . '" ' . (in_array($val, $selected) ? 'selected' : '') . '>' . __($value) . '</option>';
            } else {
                $data[] = '<option ' . $extraAttr . ' value="' . $val . '" ' . ($selected == $val ? 'selected' : '') . '>' . __($value) . '</option>';
            }
        }

        return implode(' ', $data);
    }
}

if (! function_exists('replaceUnderscoresWithSpaces')) {
    /**
     * Replace underscores with spaces in a string.
     *
     * @param string $string
     * @return string
     */
    function replaceUnderscoresWithSpaces(string $string): string
    {
        return str_replace('_', ' ', $string);
    }
}

if (! function_exists('getRecipientFromNotificationSetting')) {
    /**
     * get recipient email/SMS from notification settings for sending mail/SMS
     *
     * @param array $string
     * @return array
     */
    function getRecipientFromNotificationSetting(array $options): array
    {
        $emailSetting = \App\Models\NotificationSetting::getSettings(['nt.alias' => $options['type'], 'notification_settings.recipient_type' => $options['medium'], 'notification_settings.status' => 'Yes']);

            if ($emailSetting->isNotEmpty()) {
                $email = $emailSetting[0]['recipient'];
                $admin = \App\Models\Admin::where('email', $email)->first(['id', 'first_name', 'last_name']);
                if (!is_null($admin)) {
                    $admin = getColumnValue($admin);
                }
            } else {
                $admin = \App\Models\Admin::first(['id', 'first_name', 'last_name', 'email']);
                $email = $admin->email;

                if (!is_null($admin)) {
                    $admin = getColumnValue($admin);
                }
            }

        return ['name' => $admin, 'email' => $email];
    }
}

function calculateFee($transaction)
{
    return $transaction->charge_percentage + $transaction->charge_fixed;
}

function getFormatFee($transaction)
{
    return formatNumber(calculateFee($transaction), $transaction->currency_id);
}

function getmoneyFormatFee($transaction)
{
    return moneyFormat($transaction->currency?->symbol, getFormatFee($transaction));
}

function getPaymentMethodInfo($withdrawal)
{
    if (Withdrawal::isBankPaymentMethod($withdrawal)) {
        return Withdrawal::getBankPaymentMethodInfo($withdrawal);
    } else {
        return Withdrawal::getDefaultPaymentMethodInfo($withdrawal);
    }
}

if (!function_exists('setPaymentData')) {
    function setPaymentData($data)
    {
        session(['paymentData' => $data]);
    }
}

if (!function_exists('getPaymentData')) {

    function getPaymentData($forget=null)
    {
        $data = Session::get('paymentData');

        if (is_null($data)) {
            throw new Exception(__('Payment Session has been ended, please try again'));
        }

        if ($forget == 'forget') {
            session()->forget(['paymentData']);
        }

        return $data;
    }
}

if (!function_exists('getBankList')) {

    function getBankList($currencyId, $paymentType)
    {
        $banks = Bank::where(['currency_id' => $currencyId])->get(['id', 'bank_name', 'is_default', 'account_name', 'account_number']);
        $currencyPaymentMethods = CurrencyPaymentMethod::where('currency_id', $currencyId)
            ->where('activated_for', 'like', '%'. $paymentType .'%')
            ->where('method_data', 'like', "%bank_id%")
            ->get(['method_data']);

        $bankList = bankList($banks, $currencyPaymentMethods);

        if (count($bankList) == 0) {
            throw new DepositMoneyException(__("Banks does not exist for selected currency."));
        }
        return $bankList;
    }

 }

 if (!function_exists('bankList')) {

    function bankList($banks, $currencyPaymentMethods)
    {
        $selectedBanks = [];
        foreach ($banks as $bank) {
            foreach ($currencyPaymentMethods as $cpm) {
                if (!empty($cpm->method_data)) {
                    $methodData = json_decode($cpm->method_data);
                }
                if (isset($methodData->bank_id) && $bank->id == $methodData->bank_id) {
                    $selectedBanks[] = [
                        'id' => $bank->id,
                        'bank_name' => $bank->bank_name,
                        'is_default' => $bank->is_default,
                        'account_name' => $bank->account_name,
                        'account_number' => $bank->account_number,
                    ];
                }
            }
        }
        return $selectedBanks;
    }
}

if (!function_exists('setPaymentParam')) {

    function setPaymentParam($data)
    {
        $encodedData = urlencode(base64_encode((json_encode($data))));
        $uniqueCode = $data['uuid'];

        Parameter::updateOrCreate(
            ['unique_code' => $uniqueCode],
            ['parameter' => $encodedData]
        );

        return $uniqueCode;

    }
}

if (!function_exists('getPaymentParam')) {

    function getPaymentParam($param)
    {
        $encodeData = Parameter::where('unique_code', $param)->first();

        if ($encodeData) {
            $data = json_decode(base64_decode(urldecode($encodeData->parameter)), true);
            isTransactionExist($data['uuid']);
            return $data;
        } else {
            throw new Exception(__('Payment Url not valid'));
        }

    }
}

if (!function_exists('gatewayPaymentUrl')) {
    function gatewayPaymentUrl($data) {

        return route('gateway.pay', ['params' => setPaymentParam($data), 'gateway' => $data['gateway']]);
    }
}


 if (!function_exists('callAPI')) {

    function callAPI($method, $url, $data)
    {
        $response = null;

        switch ($method) {
            case "POST":
                $response = Http::post($url, $data);
                break;
            case "PUT":
                $response = Http::put($url, $data);
                break;
            default:
                // For other methods (default to GET)
                $response = Http::get($url, $data);
        }

        if ($response->failed()) {
            // Handle connection failure or other errors
            return null;
        }

        return $response->body();
    }

 }

 if (!function_exists('isTransactionExist')) {

    function isTransactionExist($uuid) {

        $transaction = Transaction::where(['uuid' => $uuid, 'status' => 'Success'])->first();

        if ( !is_null($transaction) ) {
            throw new Exception(__('Transaction already exist, please try again'));
        }

    }
}


if (!function_exists('isGatewayValidMethod')) {

    function isGatewayValidMethod($gateway) {

        $allowedPaymentMethods = [
            getPaymentMethodId('Stripe'),
            getPaymentMethodId('Paypal'),
            getPaymentMethodId('Coinbase'),
            getPaymentMethodId('Coinpayments'),
            getPaymentMethodId('PayUmoney'),
            getPaymentMethodId('Payeer')
        ];

        if (in_array($gateway, $allowedPaymentMethods) && (!isset(request()->execute) || request()->execute !== 'api')) {
            throw new Exception(__('Payment Failed, please try again'));
        }

        if ($gateway == getPaymentMethodId('Bank') && (!isset(request()->bank) || !isset(request()->attachment)) ) {
            throw new Exception(__('Payment Details not available'));
        }

    }
}


if (!function_exists('urlRouteExcept')) {
    function urlRouteExcept()
    {
        $segment = getFirstUrlSegment();
        $path = ['agent', 'crypto-exchange', 'campaigns', 'p2p-exchange', 'invoices', 'remittance'];

        if (in_array($segment, $path)) {
            return '^(?!'.$segment.').*$';
        }
        return '^('.$segment.').*$';
    }
}


if (!function_exists('getFirstUrlSegment')) {
    function getFirstUrlSegment()
    {
        $segments = explode('/', request()->path());
        return $segments[0];
    }
}

/**
 * Get Crypto Api log Payload Details & Confirmations for Crypto_Sent & Crypto_Received
 * @param  $transaction_type_id
 * @param  $payload
 * @param  $confirmations
 * @return array
 */

if (!function_exists('getCryptoPayloadConfirmationsDetails')) {
    function getCryptoPayloadConfirmationsDetails($transaction_type_id, $payload, $confirmations)
    {
        $arr = [];
        if (!empty($payload))  {
            if ($transaction_type_id == getTransactionTypeId('Crypto_Sent') || $transaction_type_id == getTransactionTypeId('Crypto_Received') || $transaction_type_id == getTransactionTypeId('Token_Sent') || $transaction_type_id == getTransactionTypeId('Token_Received')) {
                $payloadJson = json_decode($payload, true);
                if (isset($payloadJson['senderAddress'])) {
                    $arr['senderAddress'] = $payloadJson['senderAddress'];
                }

                if (isset($payloadJson['receiverAddress'])) {
                    $arr['receiverAddress'] = ($transaction_type_id == getTransactionTypeId('Crypto_Sent'))
                        ? $payloadJson['receiverAddress']
                        : (isset($payloadJson['address']) ? $payloadJson['address'] : $payloadJson['receiverAddress']);
                }
                if (isset($payloadJson['network_fee'])) {
                    $arr['network_fee'] = isset($payloadJson['network_fee']) ? $payloadJson['network_fee'] : 0.00000000;
                }

                if (isset($payloadJson['network'])) {
                    $arr['network'] = isset($payloadJson['network']) ? $payloadJson['network'] : null;
                }
                $arr['txId'] = $payloadJson['txid'] ?? $payloadJson['txId'];

                $arr['confirmations'] = $confirmations;
            }
        }
        return $arr;
    }
}

/**
 * Check if the request is coming from the localhost.
 *
 * @return bool
 */
if (!function_exists('isLocalhost')) {
    function isLocalhost()
    {
        $ip = request()->ip();
        return in_array($ip, ['127.0.0.1', '::1']);
    }
}


if (!function_exists('transactionTypeName')) {

    function transactionTypeName($transactionType, $platform = 'web')
    {
        if (isset($transactionType->id) && in_array($transactionType->id, getPaymoneySettings('transaction_types')['payment_sent'])) {
            return  __('Payment Sent');
        }

        if (isset($transactionType->id) &&  in_array($transactionType->id, getPaymoneySettings('transaction_types')['payment_received'])) {
            return __('Payment Received');
        }

        if (!isset($transactionType->name) && empty($transactionType->name)) {
            return '-';
        }

        return $platform == 'api' ? $transactionType->name : str_replace('_', ' ', $transactionType->name);
    }
}

if (!function_exists('getInactiveUser')) {
/**
 * Get an inactive user's ID.
 *
 * @return int
 */
    function getInactiveUser()
    {
        return \App\Models\User::where('status', 'Inactive')->first()->id;
    }
}

if (!function_exists('getSuspendedUser')) {
/**
 * Get a suspended user's ID.
 *
 * @return int
 */
    function getSuspendedUser()
    {
        return \App\Models\User::where('status', 'Suspended')->first()->id;
    }
}

if (!function_exists('getUser')) {
/**
 * Get a user's ID.
 *
 * @param string $type
 * @return int
 */
    function getUser($type)
    {
        return \App\Models\User::where('role_id', getUserRoleID($type))->first()->id;
    }
}

if (!function_exists('getAdmin')) {
/**
 * Get an admin's ID.
 *
 * @return int
 */
    function getAdmin()
    {
        return \App\Models\Admin::first()->id;
    }
}

if (!function_exists('getUserRoleID')) {
/**
 * Get the ID of the last created role for a given user type.
 *
 * @param string $type
 * @return int
 */
    function getUserRoleID($type)
    {
        return \App\Models\Role::where('customer_type', $type)->orderBy('id', 'desc')->first()->id;
    }
}

if (!function_exists('getLanguageId')) {

/**
 * Get the ID of a language based on its short name.
 *
 * @param string $shortName The short name of the language.
 * @return int The ID of the language.
 */

    function getLanguageId($shortName)
    {
        return \App\Models\Language::where('short_name', $shortName)->first()->id;
    }
}

if (!function_exists('getCurrencyId')) {
/**
 * Get the ID of a currency based on its code.
 *
 * @param string $code The code of the currency.
 * @return int The ID of the currency.
 */
    function getCurrencyId($code)
    {
        return \App\Models\Currency::where('code', $code)->first()->id;
    }
}

if (!function_exists('getCryptoBTCCurrencyId')) {
/**
 * Get the ID of a currency based on its code.
 *
 * @return int The ID of the currency.
 */
    function getCryptoBTCCurrencyId()
    {
        return \App\Models\Currency::where(['code' => 'BTC', 'type' => 'crypto'])->first()->id;
    }
}

if(!function_exists('getDefaultMerchantGroupId')) {
/**
 * Get the ID of the default merchant group.
 *
 * @return int The ID of the default merchant group.
 */
    function getDefaultMerchantGroupId()
    {
        return \App\Models\MerchantGroup::where('is_default', 'Yes')->first()->id;
    }
}

if (!function_exists('getExpressMerchantId')) {
    /**
     * Get the ID of the express merchant.
     *
     * @return int The ID of the express merchant.
     */
    function getExpressMerchantId()
    {
        return \App\Models\Merchant::where('type', 'express')->first()->id;
    }
}

if (!function_exists('getNotificationTypeId')) {
    /**
     * Get the ID of a notification type based on its alias.
     *
     * @param string $alias The alias of the notification type.
     * @return int The ID of the notification type.
     */
    function getNotificationTypeId($alias)
    {
        return \App\Models\NotificationType::where('alias', $alias)->first()->id;
    }
}

if(!function_exists('getUserByEmail')) {
    
    /**
     * Get a user's ID based on their email.
     *
     * @param string $email
     * @return int The ID of the user.
     */
    function getUserByEmail($email)
    {
        return \App\Models\User::where('email', $email)->first()->id;
    }
}

if (!function_exists('getTicketStatusId')) {
    
/**
 * Get the ID of a ticket status based on its name.
 *
 * @param string $name The name of the ticket status.
 * @return int The ID of the ticket status.
 */

    function getTicketStatusId($name)
    {
        return \App\Models\TicketStatus::where('name', $name)->first()->id;
    }
}

if (!function_exists('getTicketId')) {
    
    /**
     * Get the ID of a ticket based on its code.
     *
     * @param string $code The code of the ticket.
     * @return int The ID of the ticket.
     */
    function getTicketId($code)
    {
        return \App\Models\Ticket::where('code', $code)->first()->id;
    }
}

if (!function_exists('getCountryId')) {
    
    /**
     * Get the ID of a country based on its short name.
     *
     * @param string $shortName The short name of the country.
     * @return int The ID of the country.
     */
    function getCountryId($shortName)
    {
        return \App\Models\Country::where('short_name', $shortName)->first()->id;
    }
}

if (!function_exists('getFileId')) {
    
    /**
     * Get the ID of a file based on its short name.
     *
     * @param string $name The short name of the file.
     * @return int The ID of the file.
     */
    function getFileId($name)
    {
        return \App\Models\File::where('filename', $name)->first()->id;
    }
}

if (!function_exists('getWithdrawalId')) {
    /**
     * Get the ID of a withdrawal based on its UUID.
     *
     * @param string $uuid The UUID of the withdrawal.
     * @return int|null The ID of the withdrawal, or null if not found.
     */

    function getWithdrawalId($uuid)
    {
        return \App\Models\Withdrawal::where('uuid', $uuid)->first()->id;
    }
}

if (!function_exists('getMerchantId')) {
    
    /**
     * Get the ID of a merchant based on its UUID.
     *
     * @param string $uuid The UUID of the merchant.
     * @return int|null The ID of the merchant, or null if not found.
     */
    function getMerchantId($uuid)
    {
        return \App\Models\Merchant::where('merchant_uuid', $uuid)->first()->id;
    }
}

if (!function_exists('getBankId')) {
    
    /**
     * Get the ID of a bank based on its SWIFT CODE.
     *
     * @param string $swiftCode The SWIFT CODE of the bank.
     * @return int|null The ID of the bank, or null if not found.
     */
    function getBankId($swiftCode)
    {
        return \App\Models\Bank::where('swift_code', $swiftCode)->first()->id;
    }
}

if (!function_exists('getCurrencyExchangeWalletId')) {
    /**
     * Get the ID of a wallet based on user_id and currency_id
     *
     * @param int $userId The user ID.
     * @param int $currencyId The currency ID.
     * @return int|null The ID of the wallet, or null if not found.
     */
    function getCurrencyExchangeWalletId($userId, $currencyId)
    {
        return \App\Models\Wallet::where(['user_id' => $userId, 'currency_id' => $currencyId])->first()->id;
    }
}

if (!function_exists('getTransactionReferenceId')) {
    
    function getTransactionReferenceId($object, $uuid)
    {
        return $object::where('uuid', $uuid)->first()->id;
    }
}

if (!function_exists('getDisputeId')) {
    
    function getDisputeId($code)
    {
        return \App\Models\Dispute::where('code', $code)->first()->id;
    }
}

if (!function_exists('getCryptoProviderId')) {
    /**
     * Get the ID of a CryptoProvider based on its alias.
     *
     * @param string $alias The alias of the CryptoProvider.
     * @return int|null The ID of the CryptoProvider, or null if not found.
     */
    function getCryptoProviderId($alias) {
        return \App\Models\CryptoProvider::where('alias', $alias)->first()->id;
    }
}

if (!function_exists('getWalletId')) {

    /**
     * Get the ID of a wallet based on user_id and currency_id
     *
     * @param int $userId The user ID.
     * @param int $currencyId The currency ID.
     * @return int|null The ID of the wallet, or null if not found.
     */
    function getWalletId($userId, $currencyId) {
        return \App\Models\Wallet::where(['user_id' => $userId, 'currency_id' => $currencyId])->first()->id;
    }
}

if (!function_exists('getTransactionTypeId')) {

    /**
     * Get the ID of a transaction type based on its name.
     *
     * @param string $name The name of the transaction type.
     * @return int The ID of the transaction type.
     */
    function getTransactionTypeId($name) {
        $transactionType = \App\Models\TransactionType::where('name', $name)->first();
        return $transactionType ? $transactionType->id : null;
    }
}

if (!function_exists('getPaymentMethodId')) {

    /**
     * Get the ID of a transaction type based on its name.
     *
     * @param string $name The name of the transaction type.
     * @return int The ID of the transaction type.
     */
    function getPaymentMethodId($name) {
        $paymentMethod = \App\Models\PaymentMethod::where('name', $name)->first();
        return $paymentMethod ? $paymentMethod->id : null;
    }
}

if (!function_exists('getUSDTTokenId')) {
    /**
     * Get the ID of a currency based on its code.
     *
     * @param string $code The code of the currency.
     * @return int The ID of the currency.
     */
    function getUSDTTokenId()
    {
        return \App\Models\Currency::where(['code' => 'USDT', 'type' => 'crypto_token'])->first()->id;
    }
}




